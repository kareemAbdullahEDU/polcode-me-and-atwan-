import { useState } from "react";
import NavbarLogo from "../images/nav-logo.svg";

const NavbarSmallScreen = () => {
  const [showSidebar, setShowSidebar] = useState(false);
  const [isHide, setIsHide] = useState(false);
  const [currentView, setCurrentView] = useState("main"); // 'main' or 'services' or 'how we work'

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
    setIsHide(!isHide);
  };

  // Handlers to switch between views
  const showServicesOptionsHandler = () => {
    setCurrentView("services");
    setCurrentView("howwework");
    setCurrentView("resources");
  };

  const goBackHandler = () => {
    setCurrentView("main");
  };

  return (
    <>
      <nav className="block md:hidden relative bg-[#2e2e2e] py-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center">
            {/* logo */}
            <div>
              <img
                className="w-full object-cover block"
                src={NavbarLogo}
                alt=""
              />
            </div>
            {/* Hamburger Menu */}
            <div className="relative z-10">
              {!isHide && (
                <button onClick={toggleSidebar} className="text-white p-2">
                  {/* Hamburger Icon */}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#8A42D2"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="3" y1="12" x2="21" y2="12" />
                    <line x1="3" y1="6" x2="21" y2="6" />
                    <line x1="3" y1="18" x2="21" y2="18" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
        <div
          className={`fixed inset-0  ${
            showSidebar
              ? "transition-opacity bg-[#232325] bg-opacity-75"
              : "transition-none"
          } `}
          aria-hidden="true"
        ></div>
        {/* Sidebar */}
        <div
          className={`fixed inset-y-0 right-0 w-[90%]  bg-[white] shadow-xl transform transition-transform duration-500 ease-in-out ${
            showSidebar ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div
            className={`flex h-full flex-col overflow-y-scroll px-4 py-6 sm:px-6 bg-[#1d1a20]`}
          >
            <div className="flex items-start justify-between">
              <div>
                <img
                  className="w-full object-cover block"
                  src={NavbarLogo}
                  alt=""
                />
              </div>
              {/* Close Button */}
              <button
                onClick={toggleSidebar}
                className="relative -m-2 p-2 text-gray-400 hover:text-gray-500 flex justify-center items-center"
              >
                <span className="sr-only">Close panel</span>
                <svg
                  className="h-7 w-7"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="2"
                  stroke="#8A42D2"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>

            {/* Sidebar Content */}
            <div className="mt-8">
              <div className="flow-root">
                {currentView === "main" && (
                  <ul className="flex flex-col items-start justify-center gap-y-2 my-5">
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    <li
                      className="p-[20px] flex w-full justify-between items-center"
                      onClick={showServicesOptionsHandler} //put your showServicesOptionsHandler here
                    >
                      <a
                        className={`uppercase text-white text-[13px] `}
                        href="#"
                      >
                        services
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-chevron-right"
                      >
                        <path d="m9 18 6-6-6-6" />
                      </svg>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    {/* line */}
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a className="uppercase text-white text-[13px]" href="#">
                        projects
                      </a>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a className="uppercase text-white text-[13px]" href="#">
                        about
                      </a>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li
                      className="p-[20px] flex justify-between w-full items-center"
                      onClick={showServicesOptionsHandler}
                    >
                      <a className="uppercase text-white text-[13px]" href="#">
                        how we work
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-chevron-right"
                      >
                        <path d="m9 18 6-6-6-6" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li
                      className="p-[20px] flex justify-between w-full items-center"
                      onClick={showServicesOptionsHandler}
                    >
                      <a className="uppercase text-white text-[13px]" href="#">
                        {" "}
                        resources
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-chevron-right"
                      >
                        <path d="m9 18 6-6-6-6" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] flex w-full justify-between items-center">
                      <a className="uppercase text-white text-[13px]" href="#">
                        {" "}
                        careers
                      </a>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                  </ul>
                )}

                {/* services ul */}
                {currentView === "services" && (
                  <ul className="flex flex-col items-start justify-center gap-y-2 my-5">
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    <li
                      className="p-[20px] flex w-full justify-between items-center"
                      onClick={goBackHandler} //put your showServicesOptionsHandler here
                    >
                      <a
                        className={`uppercase text-white text-[13px] flex items-center justify-start gap-x-2`}
                        href="#"
                      >
                        <span>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="#2E2E2E"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="lucide lucide-chevron-left"
                          >
                            <path d="m15 18-6-6 6-6" />
                          </svg>
                        </span>
                        Back to main menu
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    {/* line */}
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        web development
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            Frontend
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            Backend
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        frontend development
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            react
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            vuejs
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            angular
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        backend development
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            symfony
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            laravel
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            php
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            python
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            nodejs
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            ruby on rails
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            GoLang
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        Mobile development
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            hybrid apps
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            react native
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        product design
                        <div>
                          <span className="text-white text-[12px] uppercase">
                            ui
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] uppercase">
                            ux
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        ecommerce development
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            magento
                          </span>{" "}
                          ,
                          <span className="text-white text-[12px] capitalize">
                            shopify
                          </span>
                          ,
                          <span className="text-white text-[12px] capitalize">
                            wooCommerce
                          </span>
                        </div>
                      </a>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#2E2E2E"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-plus"
                      >
                        <path d="M5 12h14" />
                        <path d="M12 5v14" />
                      </svg>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        software audit
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        team extension
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                  </ul>
                )}

                {/* how we work ul */}
                {currentView === "howwework" && (
                  <ul className="flex flex-col items-start justify-center gap-y-2 my-5">
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    <li
                      className="p-[20px] flex w-full justify-between items-center"
                      onClick={goBackHandler} //put your showServicesOptionsHandler here
                    >
                      <a
                        className={`uppercase text-white text-[13px] flex items-center justify-start gap-x-2`}
                        href="#"
                      >
                        <span>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="#2E2E2E"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="lucide lucide-chevron-left"
                          >
                            <path d="m15 18-6-6 6-6" />
                          </svg>
                        </span>
                        Back to main menu
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    {/* line */}
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        our process
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            Get to know what It's like to work with Polcode's
                            teams
                          </span>{" "}
                        </div>
                      </a>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        workshops
                        <div>
                          <span className="text-white text-[12px] capitalize">
                            A single-day scoping session helps us understand how
                            to best work <br /> together
                          </span>{" "}
                        </div>
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                  </ul>
                )}
                {/* how we work ul */}
                {currentView === "resources" && (
                  <ul className="flex flex-col items-start justify-center gap-y-2 my-5">
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    <li
                      className="p-[20px] flex w-full justify-between items-center"
                      onClick={goBackHandler} //put your showServicesOptionsHandler here
                    >
                      <a
                        className={`uppercase text-white text-[13px] flex items-center justify-start gap-x-2`}
                        href="#"
                      >
                        <span>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="#2E2E2E"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="lucide lucide-chevron-left"
                          >
                            <path d="m15 18-6-6 6-6" />
                          </svg>
                        </span>
                        Back to main menu
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>

                    {/* line */}
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        blog
                      </a>
                    </li>
                    {/* line */}
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        webinars
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        ebooks
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                    <li className="p-[20px] w-full flex justify-between items-center">
                      <a
                        className="uppercase text-white text-[13px] font-[700]"
                        href="#"
                      >
                        podcasts
                      </a>
                    </li>
                    <div className="w-full h-[0.5px] bg-[#2E2E2E]"></div>
                  </ul>
                )}
              </div>
            </div>
          </div>
          )
        </div>
      </nav>
    </>
  );
};

export default NavbarSmallScreen;
