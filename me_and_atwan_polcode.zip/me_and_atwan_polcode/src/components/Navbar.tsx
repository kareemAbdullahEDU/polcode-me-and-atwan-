import NavLogo from "../images/nav-logo.svg";
import ThirdFirstImg from "../images/third-dropdown-pic.png";
import OurBlogImgOne from "../images/our-blog-1.png";
import OurWebinarsOne from "../images/our-webinars-1.jpg";
import OurPodcasts from "../images/third-dropdown-two-pic.jpg";
import thirdDropdownImg from "../images/third-navbar-dropdown-img.png";
import NavbarSmallScreen from "./NavbarSmallScreen";

const Navbar = () => {
  return (
    <>
      {/* // large screens */}
      <nav className="hidden md:block md:p-5 relative md:bg-[#2E2E2E] py-4">
        <div className="container mx-auto">
          <div className="flex justify-center items-center">
            <ul className="flex justify-between items-center gap-x-6 nav relative">
              {/* logo */}
              <li>
                {/* <div className="w-5 h-5"> */}
                <a href="#">
                  <div className="h-full">
                    <img
                      className="w-full object-cover block h-full"
                      src={NavLogo}
                      alt=""
                    />
                  </div>
                </a>
                {/* </div> */}
              </li>
              {/* first link and dropdown  */}

              <div className="main-dropdown visible-dropdown">
                <li className="flex items-center justify-between gap-x-1 log-main">
                  <a
                    className="text-white uppercase font-bold log-main-link"
                    href="#"
                    data-toggle="dropdown"
                  >
                    SERVICES
                  </a>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-chevron-down my-animate"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                  <div className="arrow-up"></div>

                  <ul className="dropdown-content-one log">
                    <div className="container mx-auto">
                      <div className="grid md:grid-cols-3 xl:gap-x-10 lg:gap-x-6 gap-y-8 lg:pt-8 lg:pb-4 ">
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            Web <br /> development
                          </a>
                          <div className="flex justify-start gap-x-11 my-5">
                            <span className="text-white hover:text-[#8A42D2] link-hover">
                              Frontend
                            </span>
                            <span className="text-white hover:text-[#8A42D2] link-hover">
                              Backend
                            </span>
                          </div>
                        </li>
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            Frontend <br /> development
                          </a>
                          <div className="flex justify-start flex-wrap gap-x-11 my-5">
                            <span className="text-white hover:text-[#8A42D2]">
                              React
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Vue.js
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Angular
                            </span>
                          </div>
                        </li>
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            Backend <br /> development
                          </a>
                          <div className="flex justify-start flex-wrap gap-x-11 my-5">
                            <span className="text-white hover:text-[#8A42D2]">
                              Symfony
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Laravel
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              PHP
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Python
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Node.js
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Ruby on Rails
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              GoLang
                            </span>
                          </div>
                        </li>
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            Mobile <br /> development
                          </a>
                          <div className="flex justify-start flex-wrap gap-x-11 my-5">
                            <span className="text-white hover:text-[#8A42D2]">
                              Hybrid Apps
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              React Native
                            </span>
                          </div>
                        </li>
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            Product <br /> Design
                          </a>
                          <div className="flex justify-start gap-x-11 my-5">
                            <span className="text-white hover:text-[#8A42D2]">
                              UI
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              UX
                            </span>
                          </div>
                        </li>
                        <li className="text-start">
                          <a
                            href="#"
                            className="capitalize text-3xl text-white hover:text-[#8A42D2] link-hover"
                          >
                            eCommerce <br /> development
                          </a>
                          <div className="flex justify-start flex-wrap gap-x-11 my-5 text-white hover:text-[#8A42D2]">
                            <span className="text-white hover:text-[#8A42D2]">
                              Magento
                            </span>
                            <span className="text-white hover:text-[#8A42D2]">
                              Shopify
                            </span>{" "}
                            <br />
                            <span className="text-white hover:text-[#8A42D2]">
                              WooCommerce
                            </span>
                          </div>
                        </li>
                      </div>
                    </div>

                    <div className="grid py-1 px-0 bg-[#252527]">
                      <div className="container mx-auto">
                        <div className="flex justify-between items-center w-full">
                          {/* left */}
                          {/* <div className="line-after"> */}
                          <div className="flex justify-between items-center w-1/2 bg-white-dark dark:bg-dark py-4 md:px-4">
                            <h3 className="text-white text-xl ">
                              Software Audit
                            </h3>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                              className="lucide lucide-arrow-right"
                            >
                              <path d="M5 12h14" />
                              <path d="m12 5 7 7-7 7" />
                            </svg>
                          </div>
                          {/* </div> */}
                          <div className="w-[1px] h-[59px] bg-white"></div>
                          {/* right */}
                          <div className="flex justify-between items-center w-1/2 bg-white-dark dark:bg-dark py-4 md:px-4">
                            <h3 className="text-white text-xl ">
                              Team Extension
                            </h3>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                              className="lucide lucide-arrow-right"
                            >
                              <path d="M5 12h14" />
                              <path d="m12 5 7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                  </ul>
                </li>
              </div>

              <li>
                <a
                  className="text-white uppercase font-bold hover:text-[#8A42D2]"
                  href="#"
                >
                  Projects
                </a>
              </li>
              <li>
                <a
                  className="text-white uppercase font-bold hover:text-[#8A42D2]"
                  href="#"
                >
                  About
                </a>
              </li>
              <div className="main-dropdown visible-dropdown">
                <li className="flex items-center justify-between gap-x-1 log-main whitespace-nowrap">
                  <a
                    className="text-white uppercase font-bold hover:text-[#8A42D2]"
                    href="#"
                    data-toggle="dropdown"
                  >
                    How we Work
                  </a>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-chevron-down my-animate"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>

                  <div className="arrow-up-two"></div>
                  <ul className="dropdown-content-two log">
                    <div className="grid md:grid-cols-2 p-10 gap-5">
                      <li className="text-start bg-[#2E2E2E] hover:bg-[#8a42d2] hover:text-white text-white p-5 rounded-md">
                        <a href="#" className="capitalize text-3xl text-white">
                          Our Process
                        </a>
                        <div className="flex justify-start flex-wrap gap-x-11 my-5">
                          <span className="text-white">
                            Get to know what it's like to work with Polcode's
                            teams.
                          </span>
                        </div>
                      </li>
                      <li className="text-start bg-[#2E2E2E] hover:bg-[#8a42d2] hover:text-white text-white p-5 rounded-md">
                        <a
                          href="#"
                          className="capitalize text-3xl text-white hover:text-[#8A42D2]"
                        >
                          Workshops
                        </a>
                        <div className="flex justify-start flex-wrap gap-x-11 my-5 ">
                          <span className="text-white">
                            A single-day scoping session helps us understand how
                            to best work together.
                          </span>
                        </div>
                      </li>
                    </div>
                  </ul>
                </li>
              </div>
              <div className="main-dropdown visible-dropdown">
                <li className="flex items-center justify-between gap-x-1 log-main">
                  <a
                    className="text-white uppercase font-bold hover:text-[#8A42D2]"
                    href="#"
                    data-toggle="dropdown"
                  >
                    Resources
                  </a>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-chevron-down my-animate"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                  <div className="arrow-up-three"></div>
                  <ul className="dropdown-content-three log">
                    <div className="md:grid md:grid-cols-2 md:gap-10 md:p-10">
                      {/* left side */}
                      <div className="md:grid md:grid-cols-3 gap-5 bg-[#2E2E2E]">
                        {/* title, image and description */}
                        <div className="row-start-1  col-start-1  row-end-5 col-span-4">
                          {/* title */}
                          <div className="flex justify-between items-center mb-5">
                            <h2 className="text-white uppercase text-2xl">
                              Our Blog
                            </h2>
                            <h5 className="text-white uppercase font-2xl flex justify-between items-center gap-x-4 text-xl">
                              see all
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="white"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-arrow-right"
                              >
                                <path d="M5 12h14" />
                                <path d="m12 5 7 7-7 7" />
                              </svg>
                            </h5>
                          </div>

                          {/* image */}
                          <div className="flex justify-center items-center ">
                            <img
                              className="w-full object-cover block"
                              src={OurBlogImgOne}
                              alt="image-one"
                            />
                          </div>

                          <h2 className="text-white capitalize font-2xl my-5 ">
                            Lorem ipsum, dolor sit amet consectetur adipisicing
                            elit. Omnis fuga quibusdam maxime
                          </h2>
                        </div>

                        {/* paragraph */}

                        <div className="row-start-4 col-span-1 1fr  flex justify-center items-center col-start-1">
                          <div className="h-full">
                            <img
                              className="object-cover block w-full h-full"
                              src={ThirdFirstImg}
                              alt="third image"
                            />
                          </div>
                        </div>
                        <div className="col-start-2 row-start-4 col-span-3 flex justify-center items-center flex-nowrap">
                          <p className="text-white">
                            Lorem, ipsum dolor sit amet consectetur adipisicing
                            elit. Tempore dicta quis eius ducimus et odio id
                            minus deserunt iste quae!
                          </p>
                        </div>
                        <div className="row-start-5 col-span-15 col-start-1 flex justify-center items-center">
                          <div className="h-full">
                            <img
                              className="object-cover block w-full h-full"
                              src={ThirdFirstImg}
                              alt="third image"
                            />
                          </div>
                        </div>
                        <div className="col-start-2 row-start-5 col-span-3 flex justify-center items-center flex-nowrap">
                          <p className="text-white">
                            Lorem, ipsum dolor sit amet consectetur adipisicing
                            elit. Tempore dicta quis eius ducimus et odio id
                            minus deserunt iste quae!
                          </p>
                        </div>
                      </div>

                      {/* right side */}

                      <div className="grid  grid-cols-7 gap-y-5">
                        {/* first div with the first title */}
                        <div className="col-span-7 flex flex-col justify-center">
                          <div className="flex justify-between items-between">
                            <h2 className="text-white uppercase text-2xl">
                              Our Webinars
                            </h2>
                            <h5 className="text-white uppercase font-2xl flex justify-between items-center gap-x-4 text-xl">
                              see all
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="white"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-arrow-right"
                              >
                                <path d="M5 12h14" />
                                <path d="m12 5 7 7-7 7" />
                              </svg>
                            </h5>
                          </div>
                          {/* img */}
                        </div>
                        <div className="col-start-1 row-start-2 col-span-2">
                          <img
                            className="w-full object-cover block h-full"
                            src={OurWebinarsOne}
                            alt=""
                          />
                        </div>

                        <div className="col-start-5 col-span-4 row-start-2">
                          <p className="text-white">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Fuga unde nisi similique officia tempore porro
                            provident natus corrupti ullam possimus.
                          </p>
                        </div>
                        <div className="col-span-7 flex flex-col justify-center">
                          <div className="flex justify-between items-between">
                            <h2 className="text-white uppercase text-2xl">
                              Our Ebooks
                            </h2>
                            <h5 className="text-white uppercase font-2xl flex justify-between items-center gap-x-4 text-xl">
                              see all
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="white"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-arrow-right"
                              >
                                <path d="M5 12h14" />
                                <path d="m12 5 7 7-7 7" />
                              </svg>
                            </h5>
                          </div>
                          {/* img */}
                        </div>
                        <div className="col-start-1 row-start-4 col-span-3">
                          <div className="w-1/2">
                            <img
                              className="w-full object-cover block h-full"
                              src={thirdDropdownImg}
                              alt=""
                            />
                          </div>
                        </div>

                        {/* image and description */}

                        <div className="col-start-5 col-span-4 row-start-4">
                          <p className="text-white">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Fuga unde nisi similique officia tempore porro
                            provident natus corrupti ullam possimus.
                          </p>
                        </div>

                        {/* title */}

                        <div className="col-span-7 flex flex-col justify-center">
                          <div className="flex justify-between items-between">
                            <h2 className="text-white uppercase text-2xl">
                              Our Podcasts
                            </h2>
                            <h5 className="text-white uppercase font-2xl flex justify-between items-center gap-x-4 text-xl">
                              see all
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="white"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-arrow-right"
                              >
                                <path d="M5 12h14" />
                                <path d="m12 5 7 7-7 7" />
                              </svg>
                            </h5>
                          </div>
                        </div>

                        {/* image and description */}

                        <div className="col-start-1 row-start-6 col-span-2 ">
                          <img
                            className="w-full object-cover block h-full"
                            src={OurPodcasts}
                            alt=""
                          />
                        </div>

                        <div className="col-start-5 col-span-4 row-start-6">
                          <p className="text-white">
                            Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Fuga unde nisi similique officia tempore porro
                            provident natus corrupti ullam possimus.
                          </p>
                        </div>
                      </div>
                    </div>
                  </ul>
                </li>
              </div>
              <li>
                <a
                  className="text-white uppercase font-bold hover:text-[#8A42D2]"
                  href="#"
                >
                  Careers
                </a>
              </li>
              <li>
                <a className="uppercase" href="#">
                  {" "}
                  <button className="btn border border-[#8A42D2] outline-0 transition-all bg-transparent text-white hover:text-[#8A42D2] hover:border-white py-3 px-5 rounded-sm whitespace-nowrap">
                    Lets talk
                  </button>{" "}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      {/* small screens */}
      <NavbarSmallScreen />
    </>
  );
};

export default Navbar;
